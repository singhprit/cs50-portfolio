# TODO
name = input("What is your name?\n")
print("Hello, ", name)
